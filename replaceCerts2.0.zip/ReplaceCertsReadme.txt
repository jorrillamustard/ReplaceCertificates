**********----------------------------------------------------------------------------------**********
REPLACECERTS.EXE creates or uses pre-created Certificates for Site Server and Work Manager on Fidelis Enddpoint. 
**********----------------------------------------------------------------------------------**********

______________________________________________________

####Once you hit enter do not touch your Mouse.####
______________________________________________________

Format: 
replacecerts.exe -n <New Public Cert Name> <New Private Cert Name>

replacecerts.exe -d <New Public Cert Name> <New Private Cert Name>

switches:

-n : Creates new certificates using openSSL and changes the certificates in Site Server and Work Manager configurations

-d : Takes pre-created certificates as commands and changes the configurations of site server and work manager (Does not create new certificates)

**********-----------------------------**********

The creation of new certificates utilizes OPENSSL, so this application must be present on the server in order to use that switch.
The application will check if it is installed in the folder defined under OSSLDirectory. If it is not, you will be prompted to
install the application.

You must predefine the information in the "replaceCerts.exe.config" for the openSSL feature. 

The keys to predefine are as follows:

<add key="OSSLDirectory" value="C:\OpenSSL"/>     --The root directory of the OpenSSL install
<add key="CertFolder" value="C:\Comm"/>           --The folder where your certificates will be stored
<add key="keySize" value="2048"/> 		  -- The Encryption Key size for the certificate
<add key="Country" value="US"/>			  -- The Country for the Certificate Request
<add key="City" value="Columbia"/>		  -- The City for the Certificate Request
<add key="State" value="Missouri"/>		  -- The State for the Certificate Request
<add key="Orginization" value="Fidelis"/>	  -- The Orginization for the Certificate Request
<add key="OrginizationalUnit" value="Support"/>   -- The Orginizational Unit for the Certificate Request
<add key="CommonName" value="EndpointComm"/>	  -- The common name for the Certificate Request

**********-----------------------------**********

The final stage of the application restarts the Work Manager and Site Server Service to apply the Certificate change. 
Please do not interupt this process as it can cause loss of data. If Data loss is to occur/ or any other undesirable effect. 
The application makes a ".original" backup of the two configuration files it is manipulating. These files are:

siteserver.config					--located at C:\ProgramData\Resolution1\SiteServer\
Infrastructure.WorkExecutionServices.Host.exe.config    --located in the WorkManager install directory


The application then utilizes the siteserver to create a .adp12 private certificate. 
**********-----------------------------**********

Prerequisites:

OpenSSL 9.8h installed / or installed when application is run
openssl.cnf is in the \bin folder of the openSSL install directory 

